# Appunti di fisica

Oggi ripasso elettromagnetismo e le equazioni di Maxwell.
Anche un cenno a energia potenziale.
