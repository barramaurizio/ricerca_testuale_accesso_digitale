# esempio
def cerca(termine):
    return termine == 'squadlist'
